
delete from proprietario_apartamento 
where proprietario_id = 7;