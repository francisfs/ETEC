
update proprietario_apartamento set proprietario_id = 10
where prop_apto_id = 3;
select * from proprietario_apartamento;

delete from proprietario_apartamento 
where proprietario_id = 7;